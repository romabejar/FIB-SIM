# README - Practica 1 Simulació (FIB-UPC) #

- ROMABEJAR.mod: Model de Witness.
- romabejar.pdf: Document amb l'estudi del sistema.
